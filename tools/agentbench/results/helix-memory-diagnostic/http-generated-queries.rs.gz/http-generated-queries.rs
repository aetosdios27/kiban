
// DEFAULT CODE
// use helix_db::helix_engine::traversal_core::config::Config;

// pub fn config() -> Option<Config> {
//     None
// }



use bumpalo::Bump;
use heed3::RoTxn;
use helix_macros::{handler, tool_call, mcp_handler, migration};
use helix_db::{
    helix_engine::{
        reranker::{
            RerankAdapter,
            fusion::{RRFReranker, MMRReranker, DistanceMethod},
        },
        traversal_core::{
            config::{Config, GraphConfig, VectorConfig},
            ops::{
                bm25::search_bm25::SearchBM25Adapter,
                g::G,
                in_::{in_::InAdapter, in_e::InEdgesAdapter, to_n::ToNAdapter, to_v::ToVAdapter},
                out::{
                    from_n::FromNAdapter, from_v::FromVAdapter, out::OutAdapter, out_e::OutEdgesAdapter,
                },
                source::{
                    add_e::AddEAdapter,
                    add_n::AddNAdapter,
                    e_from_id::EFromIdAdapter,
                    e_from_type::EFromTypeAdapter,
                    n_from_id::NFromIdAdapter,
                    n_from_index::NFromIndexAdapter,
                    n_from_type::NFromTypeAdapter,
                    v_from_id::VFromIdAdapter,
                    v_from_type::VFromTypeAdapter
                },
                util::{
                    dedup::DedupAdapter, drop::Drop, exist::Exist, filter_mut::FilterMut,
                    filter_ref::FilterRefAdapter, intersect::IntersectAdapter, map::MapAdapter, paths::{PathAlgorithm, ShortestPathAdapter},
                    range::RangeAdapter, update::UpdateAdapter, order::OrderByAdapter,
                    aggregate::AggregateAdapter, group_by::GroupByAdapter, count::CountAdapter,
                    upsert::UpsertAdapter,
                },
                vectors::{
                    brute_force_search::BruteForceSearchVAdapter, insert::InsertVAdapter,
                    search::SearchVAdapter,
                },
            },
            traversal_value::TraversalValue,
        },
        types::{GraphError, SecondaryIndex},
        vector_core::vector::HVector,
    },
    helix_gateway::{
        embedding_providers::{EmbeddingModel, get_embedding_model},
        router::router::{HandlerInput, IoContFn},
        mcp::mcp::{MCPHandlerSubmission, MCPToolInput, MCPHandler}
    },
    node_matches, props, embed, embed_async,
    field_addition_from_old_field, field_type_cast, field_addition_from_value,
    protocol::{
        response::Response,
        value::{casting::{cast, CastType}, Value},
        date::Date,
        format::Format,
    },
    utils::{
        id::{ID, uuid_str},
        items::{Edge, Node},
        properties::ImmutablePropertiesMap,
    },
};
use sonic_rs::{Deserialize, Serialize, json};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Instant;
use chrono::{DateTime, Utc};

// Re-export scalar types for generated code
type I8 = i8;
type I16 = i16;
type I32 = i32;
type I64 = i64;
type U8 = u8;
type U16 = u16;
type U32 = u32;
type U64 = u64;
type U128 = u128;
type F32 = f32;
type F64 = f64;
    
pub fn config() -> Option<Config> {
return Some(Config {
vector_config: Some(VectorConfig {
m: Some(16),
ef_construction: Some(128),
ef_search: Some(768),
}),
graph_config: Some(GraphConfig {
secondary_indices: Some(vec![SecondaryIndex::Unique("agent_num".to_string()), SecondaryIndex::Unique("memory_id".to_string())]),
}),
db_max_size_gb: Some(10),
mcp: Some(true),
bm25: Some(false),
schema: Some(r#"{
  "schema": {
    "nodes": [
      {
        "name": "Agent",
        "properties": {
          "label": "String",
          "id": "ID",
          "agent_num": "U32"
        }
      },
      {
        "name": "Memory",
        "properties": {
          "text": "String",
          "memory_id": "String",
          "id": "ID",
          "created_at": "U64",
          "revision": "U64",
          "label": "String",
          "agent": "U32"
        }
      }
    ],
    "vectors": [],
    "edges": [
      {
        "name": "Remembers",
        "from": "Agent",
        "to": "Memory",
        "properties": {}
      }
    ]
  },
  "queries": [
    {
      "name": "Recent",
      "parameters": {
        "agent": "U32",
        "k": "U32"
      },
      "returns": [
        "memories"
      ]
    },
    {
      "name": "Update",
      "parameters": {
        "memory_id": "String",
        "text": "String",
        "revision": "U64"
      },
      "returns": [
        "memory"
      ]
    },
    {
      "name": "Noop",
      "parameters": {},
      "returns": []
    },
    {
      "name": "Remember",
      "parameters": {
        "memory_id": "String",
        "agent": "U32",
        "created_at": "U64",
        "text": "String",
        "revision": "U64"
      },
      "returns": [
        "memory"
      ]
    },
    {
      "name": "Recall",
      "parameters": {
        "memory_id": "String"
      },
      "returns": [
        "memory"
      ]
    },
    {
      "name": "InitAgent",
      "parameters": {
        "agent": "U32"
      },
      "returns": [
        "a"
      ]
    }
  ]
}"#.to_string()),
embedding_model: Some("text-embedding-ada-002".to_string()),
graphvis_node_label: None,
})
}
pub struct Agent {
    pub agent_num: u32,
}

pub struct Memory {
    pub memory_id: String,
    pub agent: u32,
    pub created_at: u64,
    pub revision: u64,
    pub text: String,
}

pub struct Remembers {
    pub from: Agent,
    pub to: Memory,
}


#[derive(Serialize, Deserialize, Clone)]
pub struct RecentInput {

pub agent: u32,
pub k: u32
}
#[derive(Serialize, Default)]
pub struct RecentMemoriesReturnType<'a> {
    pub id: &'a str,
    pub label: &'a str,
    pub memory_id: Option<&'a Value>,
    pub agent: Option<&'a Value>,
    pub created_at: Option<&'a Value>,
    pub revision: Option<&'a Value>,
    pub text: Option<&'a Value>,
}

#[handler]
pub fn Recent (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let data = input.request.in_fmt.deserialize::<RecentInput>(&input.request.body)?;
let arena = Bump::new();
let txn = db.graph_env.read_txn().map_err(|e| GraphError::New(format!("Failed to start read transaction: {:?}", e)))?;
    let memories = G::new(&db, &txn, &arena)
.n_from_index("Agent", "agent_num", &data.agent)

.out_node("Remembers")

.order_by_desc(|val| val.get_property("created_at").cloned().unwrap_or(Value::Empty))

.range(0, data.k.clone()).collect::<Result<Vec<_>, _>>()?;
let response = json!({
    "memories": memories.iter().map(|memorie| RecentMemoriesReturnType {
        id: uuid_str(memorie.id(), &arena),
        label: memorie.label(),
        memory_id: memorie.get_property("memory_id"),
        agent: memorie.get_property("agent"),
        created_at: memorie.get_property("created_at"),
        revision: memorie.get_property("revision"),
        text: memorie.get_property("text"),
    }).collect::<Vec<_>>()
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}

#[derive(Serialize, Deserialize, Clone)]
pub struct UpdateInput {

pub memory_id: String,
pub revision: u64,
pub text: String
}
#[derive(Serialize, Default)]
pub struct UpdateMemoryReturnType<'a> {
    pub id: &'a str,
    pub label: &'a str,
    pub memory_id: Option<&'a Value>,
    pub agent: Option<&'a Value>,
    pub created_at: Option<&'a Value>,
    pub revision: Option<&'a Value>,
    pub text: Option<&'a Value>,
}

#[handler(is_write)]
pub fn Update (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let data = input.request.in_fmt.deserialize::<UpdateInput>(&input.request.body)?;
let arena = Bump::new();
let mut txn = db.graph_env.write_txn().map_err(|e| GraphError::New(format!("Failed to start write transaction: {:?}", e)))?;
    let memory = {let update_tr = G::new(&db, &txn, &arena)
.n_from_index("Memory", "memory_id", &data.memory_id)
    .collect::<Result<Vec<_>, _>>()?;G::new_mut_from_iter(&db, &mut txn, update_tr.iter().cloned(), &arena)
    .update(&[("revision", Value::from(&data.revision)), ("text", Value::from(&data.text))])
    .collect_to_obj()?};
let response = json!({
    "memory": UpdateMemoryReturnType {
        id: uuid_str(memory.id(), &arena),
        label: memory.label(),
        memory_id: memory.get_property("memory_id"),
        agent: memory.get_property("agent"),
        created_at: memory.get_property("created_at"),
        revision: memory.get_property("revision"),
        text: memory.get_property("text"),
    }
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}

#[handler]
pub fn Noop (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let arena = Bump::new();
let txn = db.graph_env.read_txn().map_err(|e| GraphError::New(format!("Failed to start read transaction: {:?}", e)))?;
let response = json!({
    "data": "agentbench-noop"
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}

#[derive(Serialize, Deserialize, Clone)]
pub struct RememberInput {

pub memory_id: String,
pub agent: u32,
pub created_at: u64,
pub revision: u64,
pub text: String
}
#[derive(Serialize, Default)]
pub struct RememberMemoryReturnType<'a> {
    pub id: &'a str,
    pub label: &'a str,
    pub memory_id: Option<&'a Value>,
    pub agent: Option<&'a Value>,
    pub created_at: Option<&'a Value>,
    pub revision: Option<&'a Value>,
    pub text: Option<&'a Value>,
}

#[handler(is_write)]
pub fn Remember (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let data = input.request.in_fmt.deserialize::<RememberInput>(&input.request.body)?;
let arena = Bump::new();
let mut txn = db.graph_env.write_txn().map_err(|e| GraphError::New(format!("Failed to start write transaction: {:?}", e)))?;
    let memory = G::new_mut(&db, &arena, &mut txn)
.add_n("Memory", Some(ImmutablePropertiesMap::new(5, vec![("revision", Value::from(&data.revision)), ("text", Value::from(&data.text)), ("agent", Value::from(&data.agent)), ("memory_id", Value::from(&data.memory_id)), ("created_at", Value::from(&data.created_at))].into_iter(), &arena)), Some(&["memory_id"])).collect_to_obj()?;
    let a = G::new(&db, &txn, &arena)
.n_from_index("Agent", "agent_num", &data.agent).collect_to_obj()?;
    let edge = G::new_mut(&db, &arena, &mut txn)
.add_edge("Remembers", None, a.id(), memory.id(), false, false).collect_to_obj()?;
let response = json!({
    "memory": RememberMemoryReturnType {
        id: uuid_str(memory.id(), &arena),
        label: memory.label(),
        memory_id: memory.get_property("memory_id"),
        agent: memory.get_property("agent"),
        created_at: memory.get_property("created_at"),
        revision: memory.get_property("revision"),
        text: memory.get_property("text"),
    }
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}

#[derive(Serialize, Deserialize, Clone)]
pub struct RecallInput {

pub memory_id: String
}
#[derive(Serialize, Default)]
pub struct RecallMemoryReturnType<'a> {
    pub id: &'a str,
    pub label: &'a str,
    pub memory_id: Option<&'a Value>,
    pub agent: Option<&'a Value>,
    pub created_at: Option<&'a Value>,
    pub revision: Option<&'a Value>,
    pub text: Option<&'a Value>,
}

#[handler]
pub fn Recall (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let data = input.request.in_fmt.deserialize::<RecallInput>(&input.request.body)?;
let arena = Bump::new();
let txn = db.graph_env.read_txn().map_err(|e| GraphError::New(format!("Failed to start read transaction: {:?}", e)))?;
    let memory = G::new(&db, &txn, &arena)
.n_from_index("Memory", "memory_id", &data.memory_id).collect_to_obj()?;
let response = json!({
    "memory": RecallMemoryReturnType {
        id: uuid_str(memory.id(), &arena),
        label: memory.label(),
        memory_id: memory.get_property("memory_id"),
        agent: memory.get_property("agent"),
        created_at: memory.get_property("created_at"),
        revision: memory.get_property("revision"),
        text: memory.get_property("text"),
    }
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}

#[derive(Serialize, Deserialize, Clone)]
pub struct InitAgentInput {

pub agent: u32
}
#[derive(Serialize, Default)]
pub struct InitAgentAReturnType<'a> {
    pub id: &'a str,
    pub label: &'a str,
    pub agent_num: Option<&'a Value>,
}

#[handler(is_write)]
pub fn InitAgent (input: HandlerInput) -> Result<Response, GraphError> {
let db = Arc::clone(&input.graph.storage);
let data = input.request.in_fmt.deserialize::<InitAgentInput>(&input.request.body)?;
let arena = Bump::new();
let mut txn = db.graph_env.write_txn().map_err(|e| GraphError::New(format!("Failed to start write transaction: {:?}", e)))?;
    let a = G::new_mut(&db, &arena, &mut txn)
.add_n("Agent", Some(ImmutablePropertiesMap::new(1, vec![("agent_num", Value::from(&data.agent))].into_iter(), &arena)), Some(&["agent_num"])).collect_to_obj()?;
let response = json!({
    "a": InitAgentAReturnType {
        id: uuid_str(a.id(), &arena),
        label: a.label(),
        agent_num: a.get_property("agent_num"),
    }
});
txn.commit().map_err(|e| GraphError::New(format!("Failed to commit transaction: {:?}", e)))?;
Ok(input.request.out_fmt.create_response(&response))
}


