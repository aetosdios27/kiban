//! One background compaction worker per [`crate::db::SharedKiban`].
//!
//! Compaction is split PLAN/BUILD/COMMIT (`docs/design/compaction.md`,
//! phase 11.4): PLAN and COMMIT run under the engine lock and are
//! cheap; BUILD — the merge and sstable construction — runs here, on
//! this worker thread, outside the lock, so foreground reads and
//! writes do not wait for BUILD's engine gate. Capacity pressure can still
//! stall writers; that same worker services pending flushes at bounded input
//! checkpoints during a compaction. There is exactly one worker per engine:
//! compaction jobs cannot race with each other, and MANIFEST
//! publication stays single-writer.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use std::thread::JoinHandle;

use crate::engine_lock::ShardedRwLock;

use crate::db::{DbError, Kiban};

/// A background maintenance failure. Sticky: nothing was waiting on the
/// call that failed, so the failure must be surfaced some other way
/// (11.4 background error handling) — this is that other way.
#[derive(Debug, Clone)]
pub struct MaintenanceError(pub(crate) String);

impl std::fmt::Display for MaintenanceError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "background compaction failed: {}", self.0)
    }
}

impl std::error::Error for MaintenanceError {}

/// Raw counters for the background maintenance worker (phase 11.7,
/// extended 11.8) — facts only, no health verdicts. `compaction_running`
/// mirrors the worker's own busy flag: true for the whole PLAN/BUILD/
/// COMMIT cycle it is currently working through — a pending flush job
/// or a compaction job, since 11.8 has the one worker do both (flush
/// always first — see `run_pending_maintenance`), not narrowed to just
/// BUILD or to compaction specifically.
#[derive(Debug, Clone, Copy)]
pub struct MaintenanceStats {
    pub compaction_running: bool,
    pub compactions_completed: u64,
    pub compactions_failed: u64,
    pub compaction_input_bytes: u64,
    pub compaction_output_bytes: u64,
    pub waiting_writers: usize,
    pub write_stalls: u64,
    /// Sum of actual backpressure wait durations across callers, excluding gate acquisition.
    /// Concurrent waits overlap; this is caller time, not wall time.
    pub write_stall_ns: u64,
    /// Successful BUILD + COMMIT elapsed time, including commit gate waits,
    /// excluding pacing/PLAN and nested flush work.
    pub compaction_elapsed_ns: u64,
    pub flush_elapsed_ns: u64,
    pub flushes_completed: u64,
    pub flushes_failed: u64,
    /// Total bytes written by completed flush jobs (11.17-round-2,
    /// section 7): with `compaction_output_bytes`, gives the total
    /// physical bytes Kiban has written to SST files, the numerator for
    /// write amplification against logical bytes inserted (the
    /// denominator is the caller's own bookkeeping — Kiban doesn't
    /// track "logical bytes ever inserted" itself, since deletes and
    /// overwrites make that a workload-dependent question the caller is
    /// already in a better position to answer).
    pub flush_output_bytes: u64,
    /// Detailed maintenance phases and pressure causes.
    pub timings: MaintenanceTimings,
}

/// Maintenance phase and backpressure counters. Times are cumulative nanoseconds;
/// overlapping caller waits are not wall time. Stall counts classify the first
/// wait of each blocked call; wait durations classify every wait separately.
#[derive(Debug, Default, Clone, Copy)]
pub struct MaintenanceTimings {
    /// Blocked calls whose first observed pressure was immutable capacity only.
    pub immutable_stalls: u64,
    /// Blocked calls whose first observed pressure was L0 only.
    pub l0_stalls: u64,
    /// Blocked calls whose first observed pressure was both immutable capacity and L0.
    pub both_stalls: u64,
    /// Cumulative caller wait time attributed to immutable capacity only.
    pub immutable_wait_ns: u64,
    /// Cumulative caller wait time attributed to L0 only.
    pub l0_wait_ns: u64,
    /// Cumulative caller wait time attributed to both pressures.
    pub both_wait_ns: u64,
    /// Sum of freeze-to-BUILD delays for successful background flushes.
    pub flush_queue_ns: u64,
    /// Largest freeze-to-BUILD delay for a successful background flush.
    pub flush_queue_max_ns: u64,
    /// Successful flush BUILD time, excluding queue and COMMIT.
    pub flush_build_ns: u64,
    /// Successful flush time waiting to acquire the COMMIT engine gate.
    pub flush_commit_wait_ns: u64,
    /// Successful flush COMMIT time while holding the engine gate.
    pub flush_commit_ns: u64,
    /// Successful compaction BUILD time, excluding COMMIT and nested flush work.
    pub compaction_build_ns: u64,
    /// Successful compaction time waiting to acquire the COMMIT engine gate.
    pub compaction_commit_wait_ns: u64,
    /// Successful compaction COMMIT time while holding the engine gate.
    pub compaction_commit_ns: u64,
}

#[derive(Clone, Copy)]
pub(crate) enum WritePressure {
    Immutable,
    L0,
    Both,
}
impl WritePressure {
    pub(crate) fn from_checks(l0_ok: bool, immutable_ok: bool) -> Self {
        match (l0_ok, immutable_ok) {
            (true, false) => Self::Immutable,
            (false, true) => Self::L0,
            (false, false) => Self::Both,
            (true, true) => unreachable!("write pressure requires a failed room check"),
        }
    }
}
#[derive(Clone, Copy)]
struct PhaseTimes {
    build_ns: u64,
    commit_wait_ns: u64,
    commit_ns: u64,
}
fn nanos(d: std::time::Duration) -> u64 {
    d.as_nanos().min(u64::MAX as u128) as u64
}

struct Signal {
    /// There may be more compaction to do; the worker should look.
    wake: bool,
    /// The worker should exit at its next opportunity.
    stop: bool,
    /// True while a compaction job is actually running (for
    /// `wait_settled` in tests).
    busy: bool,
    /// Sticky: once a job fails, the worker stops attempting more
    /// compaction until the process is reopened (never retry forever).
    error: Option<MaintenanceError>,
    /// Bumped whenever a stalled writer (11.5 backpressure) needs to
    /// recheck its condition: a compaction commit succeeds, background
    /// maintenance fails, or the worker shuts down. A writer captures
    /// this value while still holding the engine lock that any commit
    /// would also need, then waits for it to change — never for a bare
    /// notify — so a commit landing between "L0 is too high" and
    /// "start waiting" can never be missed.
    progress_epoch: u64,
    /// Count of `SharedKiban` callers currently parked in a backpressure
    /// wait (11.5) — real, condvar-observable state a test can block on
    /// instead of inferring blocking from elapsed time.
    waiting_writers: usize,
    /// Phase 11.7 raw counters, all cumulative and monotonic
    /// (`saturating_add`, never reset).
    compactions_completed: u64,
    /// Bumped only for an actual failed compaction job (a BUILD error,
    /// a COMMIT error, or a caught worker panic — see `record_error`).
    /// Deliberately NOT bumped by `Maintenance::error`'s lazy dead-
    /// thread detection: that discovers an already-dead worker, which
    /// is a different kind of failure than a job that ran and failed.
    compactions_failed: u64,
    compaction_input_bytes: u64,
    compaction_output_bytes: u64,
    /// One per `SharedKiban` mutation call that genuinely had to wait
    /// for L0 room, immutable-slot room, or both, at least once — one
    /// blocked call, one stall, however many wake/recheck cycles it
    /// took (mirrors the file-cache `waits` counting rule).
    write_stalls: u64,
    write_stall_ns: u64,
    compaction_elapsed_ns: u64,
    flush_elapsed_ns: u64,
    /// Phase 11.8 counters, same conventions as the compaction ones.
    flushes_completed: u64,
    flushes_failed: u64,
    flush_output_bytes: u64,
    timings: MaintenanceTimings,
}

/// Owns the worker thread and the signal used to wake, stop, and query
/// it. One `Maintenance` per `SharedKiban` engine (shared by every
/// clone of that handle).
pub(crate) struct Maintenance {
    /// Count of live `SharedKiban` handles sharing this worker; the
    /// last one to drop stops and joins the thread (no Arc cycle: the
    /// worker holds strong refs to the engine and to this struct, but
    /// nothing holds a strong ref back to `SharedKiban` itself, so
    /// shutdown is driven by this explicit count, not by refcount
    /// polling).
    handles: AtomicUsize,
    state: Mutex<Signal>,
    condvar: Condvar,
    thread: Mutex<Option<JoinHandle<()>>>,
    #[cfg(test)]
    test: TestHooks,
}

impl Maintenance {
    pub(crate) fn spawn(engine: Arc<ShardedRwLock<Kiban>>) -> Arc<Maintenance> {
        let m = Arc::new(Maintenance {
            handles: AtomicUsize::new(1),
            state: Mutex::new(Signal {
                wake: false,
                stop: false,
                busy: false,
                error: None,
                progress_epoch: 0,
                waiting_writers: 0,
                compactions_completed: 0,
                compactions_failed: 0,
                compaction_input_bytes: 0,
                compaction_output_bytes: 0,
                write_stalls: 0,
                write_stall_ns: 0,
                compaction_elapsed_ns: 0,
                flush_elapsed_ns: 0,
                flushes_completed: 0,
                flushes_failed: 0,
                flush_output_bytes: 0,
                timings: MaintenanceTimings::default(),
            }),
            condvar: Condvar::new(),
            thread: Mutex::new(None),
            #[cfg(test)]
            test: TestHooks::default(),
        });
        let worker = m.clone();
        let handle = std::thread::spawn(move || worker_loop(engine, worker));
        *m.thread.lock().unwrap() = Some(handle);
        m
    }

    /// Registers one more `SharedKiban` handle sharing this worker.
    pub(crate) fn add_handle(&self) {
        self.handles.fetch_add(1, Ordering::AcqRel);
    }

    /// Releases one handle. Stops and joins the worker iff this was the
    /// last live handle (race-free: `fetch_sub` returns the pre-
    /// decrement count, so exactly one caller ever observes 1).
    pub(crate) fn drop_handle(&self) {
        if self.handles.fetch_sub(1, Ordering::AcqRel) == 1 {
            self.shutdown();
        }
    }

    fn shutdown(&self) {
        {
            let mut s = self.state.lock().unwrap();
            s.stop = true;
            s.wake = true;
            s.progress_epoch += 1;
        }
        self.condvar.notify_all();
        if let Some(h) = self.thread.lock().unwrap().take() {
            let _ = h.join();
        }
    }

    /// Tells the worker there may be more compaction to do.
    pub(crate) fn wake(&self) {
        {
            self.state.lock().unwrap().wake = true;
        }
        self.condvar.notify_all();
    }

    /// The most recent background failure, if any. Also detects a
    /// worker thread that exited without being told to (a dead
    /// maintenance thread nobody asked to die is itself a failure).
    pub(crate) fn error(&self) -> Option<MaintenanceError> {
        let dead = match self.thread.lock().unwrap().as_ref() {
            Some(h) => h.is_finished(),
            None => false, // already joined via a clean shutdown
        };
        let mut s = self.state.lock().unwrap();
        let became_dead = dead && s.error.is_none() && !s.stop;
        if became_dead {
            s.error = Some(MaintenanceError(
                "maintenance worker thread exited unexpectedly".to_string(),
            ));
            s.progress_epoch += 1;
        }
        let result = s.error.clone();
        drop(s);
        if became_dead {
            // A stalled writer may be parked on exactly this transition;
            // nothing else would ever wake it (11.5).
            self.condvar.notify_all();
        }
        result
    }

    /// Current progress epoch (11.5 backpressure). Must be read while
    /// still holding the engine lock, immediately after observing L0
    /// too high — see `SharedKiban::wait_for_write_room` for why that
    /// ordering is what makes the wait below race-free.
    pub(crate) fn progress_epoch(&self) -> u64 {
        self.state.lock().unwrap().progress_epoch
    }

    /// Blocks until the progress epoch has moved past `since`, or
    /// maintenance has failed, or the worker is stopping. Never a bare
    /// sleep or poll: the check and the wait share one lock, so a
    /// commit that bumps the epoch between a caller's read of it and
    /// this call can never be missed.
    pub(crate) fn wait_for_progress(&self, since: u64) {
        let mut s = self.state.lock().unwrap();
        while s.progress_epoch == since && s.error.is_none() && !s.stop {
            s = self.condvar.wait(s).unwrap();
        }
    }

    /// Times only the backpressure condvar wait, with no clock reads on unstalled calls.
    pub(crate) fn wait_for_write_progress(&self, since: u64, pressure: WritePressure) {
        let start = std::time::Instant::now();
        self.wait_for_progress(since);
        let elapsed = start.elapsed().as_nanos().min(u64::MAX as u128) as u64;
        let mut s = self.state.lock().unwrap();
        s.write_stall_ns = s.write_stall_ns.saturating_add(elapsed);
        let classified = match pressure {
            WritePressure::Immutable => &mut s.timings.immutable_wait_ns,
            WritePressure::L0 => &mut s.timings.l0_wait_ns,
            WritePressure::Both => &mut s.timings.both_wait_ns,
        };
        *classified = classified.saturating_add(elapsed);
    }

    /// Whether the worker has been told to stop. A writer that somehow
    /// wakes with nothing else changed (no epoch bump, no error) but
    /// finds this true must give up rather than loop forever waiting
    /// for a worker that is going away.
    pub(crate) fn is_stopped(&self) -> bool {
        self.state.lock().unwrap().stop
    }

    /// Marks entry into / exit from a backpressure wait (11.5). Paired
    /// calls around `wait_for_progress` in
    /// `SharedKiban::wait_for_write_room`.
    pub(crate) fn writer_started_waiting(&self) {
        let mut s = self.state.lock().unwrap();
        s.waiting_writers += 1;
        drop(s);
        self.condvar.notify_all();
    }

    pub(crate) fn writer_stopped_waiting(&self) {
        self.state.lock().unwrap().waiting_writers -= 1;
    }

    /// How many `SharedKiban` callers are, right now, genuinely parked
    /// waiting for L0 room — not inferred from elapsed time. The same
    /// fact is also part of `stats()` (11.7), which reads the field
    /// directly under its own already-held lock rather than calling
    /// this (a `Mutex` is not reentrant).
    #[cfg(test)]
    pub(crate) fn waiting_writers(&self) -> usize {
        self.state.lock().unwrap().waiting_writers
    }

    /// Records that one `SharedKiban` mutation call genuinely had to
    /// wait for L0 room — call exactly once per call that blocks, not
    /// once per wake/recheck cycle within it (11.7).
    pub(crate) fn record_write_stall(&self, pressure: WritePressure) {
        let mut s = self.state.lock().unwrap();
        s.write_stalls = s.write_stalls.saturating_add(1);
        let classified = match pressure {
            WritePressure::Immutable => &mut s.timings.immutable_stalls,
            WritePressure::L0 => &mut s.timings.l0_stalls,
            WritePressure::Both => &mut s.timings.both_stalls,
        };
        *classified = classified.saturating_add(1);
    }

    /// A cheap, lock-once read of every maintenance counter (11.7). No
    /// I/O, no effect on any counter it reads.
    pub(crate) fn stats(&self) -> MaintenanceStats {
        let s = self.state.lock().unwrap();
        MaintenanceStats {
            compaction_running: s.busy,
            compactions_completed: s.compactions_completed,
            compactions_failed: s.compactions_failed,
            compaction_input_bytes: s.compaction_input_bytes,
            compaction_output_bytes: s.compaction_output_bytes,
            waiting_writers: s.waiting_writers,
            write_stalls: s.write_stalls,
            write_stall_ns: s.write_stall_ns,
            compaction_elapsed_ns: s.compaction_elapsed_ns,
            flush_elapsed_ns: s.flush_elapsed_ns,
            flushes_completed: s.flushes_completed,
            flushes_failed: s.flushes_failed,
            flush_output_bytes: s.flush_output_bytes,
            timings: s.timings,
        }
    }

    /// Blocks until at least one writer is genuinely parked in a
    /// backpressure wait — for deterministic tests, instead of
    /// inferring blocking from elapsed time.
    #[cfg(test)]
    pub(crate) fn wait_until_writer_waiting(&self) {
        let mut s = self.state.lock().unwrap();
        while s.waiting_writers == 0 {
            s = self.condvar.wait(s).unwrap();
        }
    }
}

fn worker_loop(engine: Arc<ShardedRwLock<Kiban>>, m: Arc<Maintenance>) {
    loop {
        {
            let mut s = m.state.lock().unwrap();
            while !s.wake && !s.stop {
                s = m.condvar.wait(s).unwrap();
            }
            if s.stop {
                return;
            }
            s.wake = false;
            s.busy = true;
        }

        if m.state.lock().unwrap().error.is_none() {
            // A stalled writer (11.5) may be parked waiting for exactly
            // the progress this cycle would make. If this panics — a
            // bug, not an expected runtime condition — that must still
            // become a recorded, wake-triggering failure rather than a
            // silently vanished thread nobody notified.
            let engine = &engine;
            let m_ref = &m;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                run_pending_maintenance(engine, m_ref);
            }));
            if let Err(payload) = outcome {
                record_error(
                    &m,
                    format!("worker thread panicked: {}", panic_message(&payload)),
                );
            }
        }

        {
            let mut s = m.state.lock().unwrap();
            s.busy = false;
        }
        m.condvar.notify_all();

        if m.state.lock().unwrap().stop {
            return;
        }
    }
}

fn panic_message(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(s) = payload.downcast_ref::<&str>() {
        (*s).to_string()
    } else if let Some(s) = payload.downcast_ref::<String>() {
        s.clone()
    } else {
        "non-string panic payload".to_string()
    }
}

/// L0 pressure captured in the same lock hold as a flush/compaction
/// commit (11.17-D), used only to decide whether the worker should
/// pace itself before its next job — never anything policy-relevant
/// (L0 admission, backpressure) depends on it.
struct MaintenancePressure {
    l0_count: usize,
    l0_write_stall_trigger: usize,
    pacing_enabled: bool,
    /// 11.17-round-3, section 8: the governor's mode at capture time —
    /// still used to pick `pacing_delay`'s ceiling (see below).
    /// `Balanced` for every non-Governor scheduler (see
    /// `Kiban::governor_mode`), in which case this changes nothing
    /// about `pace()`'s existing behavior.
    governor_mode: crate::governor::GovernorMode,
    /// 11.17-round-3.1: the governor's continuous pressure signal at
    /// capture time (`Kiban::governor_pressure`) — 0.0 forever for
    /// every non-Governor scheduler, which (combined with `Balanced`
    /// above) reproduces the original flat `PACE_DELAY` exactly via
    /// `pacing_delay(Balanced, 0.0)`.
    governor_pressure: f64,
}

impl MaintenancePressure {
    fn capture(guard: &Kiban) -> Self {
        MaintenancePressure {
            l0_count: guard.l0_count(),
            l0_write_stall_trigger: guard.options().l0_write_stall_trigger,
            pacing_enabled: guard.options().maintenance_pacing_enabled,
            governor_mode: guard.governor_mode(),
            governor_pressure: guard.governor_pressure(),
        }
    }

    /// Sole point of this type: `run_pending_maintenance`'s inner loop
    /// otherwise runs PLAN -> BUILD -> COMMIT back to back with no
    /// pacing at all, each commit briefly excluding every foreground
    /// reader (engine_lock's writer-excludes-all-shards protocol).
    /// Under a sustained flood of small, fast jobs (many writes against
    /// small buffers producing many small flushes/compactions in
    /// quick succession) that can mean thousands of back-to-back full
    /// engine-gate acquisitions with no gap for a foreground reader to
    /// actually get scheduled in between — even though each individual
    /// acquisition is brief, measured foreground GET p99 under exactly
    /// this shape of pressure was ~100x baseline (11.17-D stress
    /// results).
    ///
    /// Pacing is a plain `sleep`, not a lock-holding wait, and fires
    /// only when L0 has real headroom below its hard write-stall
    /// ceiling — i.e. maintenance is not racing to prevent a stall.
    /// Once L0 is within `HEADROOM_DIVISOR` of that ceiling, pacing
    /// stops immediately and the worker goes back to running flat out
    /// (self-stabilizing in practice: the 11.17-D stress workload
    /// settles at a roughly constant L0 count well under the ceiling
    /// rather than growing unbounded, across every delay tested). This
    /// never slows draining a genuine backlog, and the fixed delay is
    /// small enough to be immaterial next to real BUILD time (disk
    /// I/O, table construction) for anything but a degenerate
    /// tiny-file workload — precisely the pathological churn case this
    /// exists to pace.
    ///
    /// `PACE_DELAY` was swept (0/10/30/100us) against the 11.17-D
    /// stress workload: 10-30us already captures most of the
    /// foreground win (GET p99 ~120us -> ~50us) while keeping PUT p99
    /// flat-to-better than unpaced (write-lock contention drops enough
    /// to offset the extra stalls); 100us pushes GET p99 lower still
    /// (~32us) but starts visibly costing PUT p99. 20us was chosen as
    /// the balance.
    ///
    /// 11.17-round-3.1: pacing aggressiveness is now driven by the
    /// governor's *continuous* pressure signal (`pacing_delay`), not a
    /// flat per-mode multiplier. The mode still selects which delay
    /// *ceiling* applies (`READ_PROTECT` gets a higher one — foreground
    /// reads are already under sustained load, spend a little more
    /// background cadence protecting them — see `pacing_delay`), but
    /// the actual delay within that ceiling now varies smoothly with
    /// pressure instead of jumping between three fixed values the
    /// instant a hysteresis-gated mode transition lands. This is what
    /// fixed a real, measured problem: `WRITE_EMERGENCY`'s old flat
    /// delay stayed at its most-aggressive value through the mode's
    /// exit hysteresis-lag tail (L0 already recovered, mode not yet
    /// caught up), and a phase-changing benchmark caught a burst of
    /// under-paced COMMITs landing right as a workload shifted to read-
    /// heavy, spiking PUT p999 to several milliseconds. Pressure reacts
    /// every call, not every mode transition, so that tail now decays
    /// smoothly instead of stepping.
    ///
    /// The early return below is unchanged from before pressure
    /// existed: pacing is skipped entirely whenever L0 has no real
    /// headroom (within `HEADROOM_DIVISOR` of the stall trigger) —
    /// draining a genuine backlog is never slowed down, for every
    /// scheduler, Governor or not.
    fn pace(&self) {
        const HEADROOM_DIVISOR: usize = 2;
        if !self.pacing_enabled
            || self.l0_count.saturating_mul(HEADROOM_DIVISOR) >= self.l0_write_stall_trigger
        {
            return;
        }
        let delay = crate::governor::pacing_delay(self.governor_mode, self.governor_pressure);
        std::thread::sleep(delay);
    }
}

/// Runs every job the engine currently needs — flush, then compaction
/// (11.8: memory pressure outranks maintenance debt) — with BUILD
/// moved off the lock for both. Compaction's own priority order within
/// itself (L0 first, then a level cascade) is unchanged, mirroring
/// `Kiban::maybe_compact`'s decision function exactly.
///
/// At most one immutable memtable can ever be pending (this phase's
/// own rule), so at most one flush job runs per pass through the outer
/// loop; `continue` after committing one so the loop rechecks — a
/// fresh freeze can land while this job's BUILD was running unlocked.
fn run_pending_maintenance(engine: &Arc<ShardedRwLock<Kiban>>, m: &Arc<Maintenance>) {
    let mut cascade_level = 1u32;
    loop {
        // 11.17-round-3.3: PLAN is read-only against `version` and
        // reserves its own bookkeeping (`next_file_number`, `governor`)
        // through their own atomic/mutex, so it no longer needs the
        // full 8-shard reader-excluding gate `write()` requires — only
        // COMMIT (which actually mutates `version`) does. This is what
        // was measured to cause elevated foreground PUT tail during a
        // read-heavy recovery phase: every PLAN attempt, including one
        // that finds nothing to do, used to queue behind `writer_serial`
        // and drain every shard exactly like a real mutation.
        match run_one_flush(engine, m, false) {
            Ok(true) => continue,
            Ok(false) => (),
            Err(_) => return, // run_one_flush recorded the sticky failure
        }

        let plan = {
            let Ok(guard) = engine.read() else {
                return;
            };
            guard.plan_next_compaction(&mut cascade_level)
        };
        let Some(plan) = plan else { return };

        #[cfg(test)]
        m.test.before_build();

        let started = std::time::Instant::now();
        let mut flush_time = std::time::Duration::ZERO;
        let outputs = plan.build_with_progress(|| {
            #[cfg(test)]
            m.test.before_compaction_progress.hit();
            let flush_started = std::time::Instant::now();
            if run_one_flush(engine, m, true)? {
                #[cfg(test)]
                m.test.after_compaction_flush.hit();
                flush_time += flush_started.elapsed();
            }
            Ok(())
        });
        match outputs {
            Ok(outputs) => {
                // Nested flush work belongs to flush counters, not compaction.
                let build_ns = nanos(started.elapsed().saturating_sub(flush_time));
                let gate_started = std::time::Instant::now();
                let (committed, pressure, phases) = {
                    let Ok(mut guard) = engine.write() else {
                        return;
                    };
                    let commit_wait_ns = nanos(gate_started.elapsed());
                    let commit_started = std::time::Instant::now();
                    let committed = guard.commit_compaction(plan, outputs);
                    let commit_ns = nanos(commit_started.elapsed());
                    (
                        committed,
                        MaintenancePressure::capture(&guard),
                        PhaseTimes {
                            build_ns,
                            commit_wait_ns,
                            commit_ns,
                        },
                    )
                };
                match committed {
                    // A successful commit is exactly the progress a
                    // stalled writer (11.5) is waiting to recheck
                    // against — wake it now, not after the whole
                    // cascade finishes.
                    Ok(outcome) => record_compaction_success(
                        m,
                        outcome,
                        started.elapsed().saturating_sub(flush_time),
                        phases,
                    ),
                    Err(e) => {
                        record_error(m, e.to_string());
                        return;
                    }
                }
                pressure.pace();
            }
            Err(e) => {
                record_error(m, e.to_string());
                return;
            }
        }
    }
}

/// Service one frozen generation on the same worker, using the normal durable
/// flush path. During an unfinished compaction, do not fill L0 past its hard
/// ceiling: complete that compaction before servicing further flushes. One job
/// per checkpoint bounds how much new writing can postpone compaction progress.
fn run_one_flush(
    engine: &Arc<ShardedRwLock<Kiban>>,
    m: &Arc<Maintenance>,
    during_compaction: bool,
) -> Result<bool, DbError> {
    let result: Result<bool, DbError> = (|| {
        let plan = {
            let guard = engine.read().map_err(|_| {
                DbError::Maintenance(MaintenanceError(
                    "engine gate poisoned during flush planning".into(),
                ))
            })?;
            if during_compaction && guard.l0_count() >= guard.options().l0_write_stall_trigger {
                return Ok(false);
            }
            guard.plan_flush()
        };
        let Some(plan) = plan else { return Ok(false) };
        #[cfg(test)]
        m.test.before_flush_build();
        let started = std::time::Instant::now();
        let queue_ns = nanos(started.duration_since(plan.queued_at));
        let output = plan.build()?;
        let output_bytes = output.size;
        let build_ns = nanos(started.elapsed());
        let gate_started = std::time::Instant::now();
        let (pressure, phases) = {
            let mut guard = engine.write().map_err(|_| {
                DbError::Maintenance(MaintenanceError(
                    "engine gate poisoned during flush commit".into(),
                ))
            })?;
            let commit_wait_ns = nanos(gate_started.elapsed());
            let commit_started = std::time::Instant::now();
            guard.commit_flush(plan, output)?;
            let commit_ns = nanos(commit_started.elapsed());
            (
                MaintenancePressure::capture(&guard),
                PhaseTimes {
                    build_ns,
                    commit_wait_ns,
                    commit_ns,
                },
            )
        };
        record_flush_success(m, output_bytes, started.elapsed(), queue_ns, phases);
        pressure.pace();
        Ok(true)
    })();
    if let Err(e) = &result {
        record_flush_error(m, e.to_string());
    }
    result
}

fn record_flush_success(
    m: &Arc<Maintenance>,
    output_bytes: u64,
    elapsed: std::time::Duration,
    queue_ns: u64,
    phases: PhaseTimes,
) {
    {
        let mut s = m.state.lock().unwrap();
        s.flush_elapsed_ns = s
            .flush_elapsed_ns
            .saturating_add(elapsed.as_nanos().min(u64::MAX as u128) as u64);
        s.timings.flush_queue_ns = s.timings.flush_queue_ns.saturating_add(queue_ns);
        s.timings.flush_queue_max_ns = s.timings.flush_queue_max_ns.max(queue_ns);
        s.timings.flush_build_ns = s.timings.flush_build_ns.saturating_add(phases.build_ns);
        s.timings.flush_commit_wait_ns = s
            .timings
            .flush_commit_wait_ns
            .saturating_add(phases.commit_wait_ns);
        s.timings.flush_commit_ns = s.timings.flush_commit_ns.saturating_add(phases.commit_ns);
        s.flushes_completed = s.flushes_completed.saturating_add(1);
        s.flush_output_bytes = s.flush_output_bytes.saturating_add(output_bytes);
        s.progress_epoch += 1;
    }
    m.condvar.notify_all();
}

fn record_flush_error(m: &Arc<Maintenance>, msg: String) {
    {
        let mut s = m.state.lock().unwrap();
        s.error = Some(MaintenanceError(msg));
        s.flushes_failed = s.flushes_failed.saturating_add(1);
        s.progress_epoch += 1;
    }
    m.condvar.notify_all();
}

fn record_compaction_success(
    m: &Arc<Maintenance>,
    outcome: crate::db::CompactionOutcome,
    elapsed: std::time::Duration,
    phases: PhaseTimes,
) {
    {
        let mut s = m.state.lock().unwrap();
        s.timings.compaction_build_ns = s
            .timings
            .compaction_build_ns
            .saturating_add(phases.build_ns);
        s.timings.compaction_commit_wait_ns = s
            .timings
            .compaction_commit_wait_ns
            .saturating_add(phases.commit_wait_ns);
        s.timings.compaction_commit_ns = s
            .timings
            .compaction_commit_ns
            .saturating_add(phases.commit_ns);
        s.compaction_elapsed_ns = s
            .compaction_elapsed_ns
            .saturating_add(elapsed.as_nanos().min(u64::MAX as u128) as u64);
        s.compactions_completed = s.compactions_completed.saturating_add(1);
        s.compaction_input_bytes = s.compaction_input_bytes.saturating_add(outcome.input_bytes);
        s.compaction_output_bytes = s
            .compaction_output_bytes
            .saturating_add(outcome.output_bytes);
        s.progress_epoch += 1;
    }
    m.condvar.notify_all();
}

fn record_error(m: &Arc<Maintenance>, msg: String) {
    {
        let mut s = m.state.lock().unwrap();
        s.error = Some(MaintenanceError(msg));
        s.compactions_failed = s.compactions_failed.saturating_add(1);
        s.progress_epoch += 1;
    }
    m.condvar.notify_all();
}

// ---------------------------------------------------------- test hooks
//
// Deterministic control for the worker thread: freeze it at a known
// point (after PLAN, before BUILD) instead of sleeping, and run a
// one-shot closure ON the worker thread before it resumes — needed
// because fault injection (`sys::install_fault`) is thread-local, so a
// fault meant for the worker's own I/O must be installed from the
// worker's own thread.

#[cfg(test)]
#[derive(Default, Clone, Copy, PartialEq, Eq)]
enum CheckpointState {
    #[default]
    Idle,
    Armed,
    Reached,
}

#[cfg(test)]
#[derive(Default)]
struct Checkpoint {
    state: Mutex<CheckpointState>,
    condvar: Condvar,
}

#[cfg(test)]
impl Checkpoint {
    fn arm(&self) {
        *self.state.lock().unwrap() = CheckpointState::Armed;
    }

    /// Worker side: a no-op unless armed; if armed, announces it has
    /// reached this point and blocks until a test releases it.
    fn hit(&self) {
        let mut s = self.state.lock().unwrap();
        if *s != CheckpointState::Armed {
            return;
        }
        *s = CheckpointState::Reached;
        self.condvar.notify_all();
        while *s == CheckpointState::Reached {
            s = self.condvar.wait(s).unwrap();
        }
    }

    fn wait_reached(&self) {
        let mut s = self.state.lock().unwrap();
        while *s != CheckpointState::Reached {
            s = self.condvar.wait(s).unwrap();
        }
    }

    fn wait_reached_bounded(&self) -> bool {
        let state = self.state.lock().unwrap();
        let (state, _) = self
            .condvar
            .wait_timeout_while(state, std::time::Duration::from_secs(5), |s| {
                *s != CheckpointState::Reached
            })
            .unwrap();
        *state == CheckpointState::Reached
    }

    fn release(&self) {
        *self.state.lock().unwrap() = CheckpointState::Idle;
        self.condvar.notify_all();
    }
}

#[cfg(test)]
#[derive(Default)]
struct TestHooks {
    /// Compaction's build point (11.4).
    before_build: Checkpoint,
    /// A pending flush's build point (11.8) — deliberately a separate
    /// checkpoint from compaction's: since 11.8, `SharedKiban::flush()`
    /// and auto-freeze both route their SST construction through this
    /// same worker, and a test arming *compaction's* checkpoint (e.g.
    /// to freeze the worker mid-cascade while seeding L0 tables via
    /// ordinary `flush()` calls) must not also freeze every flush
    /// those seed calls themselves depend on to ever return.
    before_flush_build: Checkpoint,
    before_compaction_progress: Checkpoint,
    after_compaction_flush: Checkpoint,
    pending: Mutex<Option<Box<dyn FnOnce() + Send>>>,
}

#[cfg(test)]
impl TestHooks {
    /// Blocks first (if armed), THEN runs any pending injected closure —
    /// so a test can wait until the worker is frozen here, install a
    /// fault via `inject_on_worker`, and release: the fault always lands
    /// right before BUILD, never before the freeze that would let the
    /// test miss the window to install it.
    fn before_build(&self) {
        self.before_build.hit();
        if let Some(f) = self.pending.lock().unwrap().take() {
            f();
        }
    }

    /// Same discipline as `before_build`, for a pending flush's BUILD.
    fn before_flush_build(&self) {
        self.before_flush_build.hit();
        if let Some(f) = self.pending.lock().unwrap().take() {
            f();
        }
    }
}

#[cfg(test)]
impl Maintenance {
    /// Freezes the worker the next time it reaches the point after PLAN
    /// and before a COMPACTION's BUILD starts.
    pub(crate) fn arm_before_build(&self) {
        self.test.before_build.arm();
    }

    /// Blocks until the worker has reached that point and is frozen
    /// there.
    pub(crate) fn wait_before_build_reached(&self) {
        self.test.before_build.wait_reached();
    }

    /// Lets a frozen worker continue into BUILD.
    pub(crate) fn release_before_build(&self) {
        self.test.before_build.release();
    }

    /// Freezes the worker the next time it reaches the point after PLAN
    /// and before a pending FLUSH's BUILD starts (11.8).
    pub(crate) fn arm_before_flush_build(&self) {
        self.test.before_flush_build.arm();
    }

    /// Blocks until the worker has reached that point and is frozen
    /// there.
    pub(crate) fn wait_before_flush_build_reached(&self) {
        self.test.before_flush_build.wait_reached();
    }

    /// Lets a frozen worker continue into a flush's BUILD.
    pub(crate) fn release_before_flush_build(&self) {
        self.test.before_flush_build.release();
    }

    /// Runs `f` on the worker thread itself, once, immediately before
    /// its next BUILD — e.g. `sys::install_fault(n)`, which is
    /// thread-local and must be set on the thread that will do the I/O.
    pub(crate) fn inject_on_worker(&self, f: impl FnOnce() + Send + 'static) {
        *self.test.pending.lock().unwrap() = Some(Box::new(f));
    }

    pub(crate) fn arm_before_compaction_progress(&self) {
        self.test.before_compaction_progress.arm();
    }
    pub(crate) fn wait_before_compaction_progress(&self) -> bool {
        self.test.before_compaction_progress.wait_reached_bounded()
    }
    pub(crate) fn release_before_compaction_progress(&self) {
        self.test.before_compaction_progress.release();
    }
    pub(crate) fn arm_after_compaction_flush(&self) {
        self.test.after_compaction_flush.arm();
    }
    pub(crate) fn wait_after_compaction_flush(&self) -> bool {
        self.test.after_compaction_flush.wait_reached_bounded()
    }
    pub(crate) fn release_after_compaction_flush(&self) {
        self.test.after_compaction_flush.release();
    }

    /// Blocks until the worker is idle and has no outstanding wake —
    /// i.e. it has settled, rather than sleeping a guessed duration.
    pub(crate) fn wait_settled(&self) {
        let mut s = self.state.lock().unwrap();
        while s.busy || s.wake {
            s = self.condvar.wait(s).unwrap();
        }
    }
}
